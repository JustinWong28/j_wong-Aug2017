
public class Hello_world {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}System.out.println("/\\"
			System.out.println()

}
