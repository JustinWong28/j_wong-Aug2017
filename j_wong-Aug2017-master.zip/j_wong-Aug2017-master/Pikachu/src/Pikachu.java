//Justin Wong
//Pikachu project 1
//period 1
public class Pikachu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("\tPikachu welcomes you to the world of Pokemon!");
System.out.println("\t\t\t   (\\__/)");
System.out.println("\t\t\t   (o^.^)");
System.out.println("\t\t\t  z(_(\")(\")");
}
}