
// Justin Wong
// My first java project. It will compare print and println
// August 22, 2017

public class Project2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
	System.out.println("hello this is Justin Wong's project 2!!!");
	
	System.out.print("hello this is Justin Wong's project 2!!!");
	}

}
